import string

def main():

	outfile = open("subjectList.txt" , "w")

	fname = raw_input("Enter File Name: ")
	
	if len(fname) == 0:
		print "you must enter a file name"
		fname = raw_input("Enter File Name: ")
	try:
		infile = open(fname, "r")
	except:
		print "File not found, please start over."
		exit()

	print "Reading File..."

	resCount = 0

	for line in infile: 
		
		decsrPrint = ''
		qualPrint = ''
		
		chunk = string.split(line)
		
		chunkCount = len(chunk)
		
		print str(chunk)+" "+str(chunkCount)
		
		if chunkCount == 0: 
			continue
		if chunkCount >= 1:
			chunklet = str(chunk[0])
			
			if chunklet.startswith( '<PMID>' ):
				idLeftRemove = chunklet[6:]
				idNum = idLeftRemove[:8]
				resCount = resCount+1
				print idNum
				outfile.write("\n"+str(idNum)+" "+str(resCount)+"\n")
					
			if chunklet.startswith('<DescriptorName'):
				
				combineChunk = ''
				
				for count in chunk:
					combineChunk += count
								
				cutOne = int(combineChunk.find('>'))
				cutOneOver = combineChunk[cutOne+1:]
				
				cutTwo = int(cutOneOver.find('<'))
				cutTwoOver = cutOneOver[:cutTwo]
				
				decsrPrint = str(cutTwoOver)
				
				outfile.write(str(cutTwoOver))
				outfile.write(str("\n"))
				
			if chunklet.startswith('<QualifierName'):
				combineChunkQ = ''
				
				for count in chunk:
					combineChunkQ += count
								
				cutOneQ = int(combineChunkQ.find('>'))
				cutOneOverQ = combineChunkQ[cutOne:]
				
				cutTwoQ = int(cutOneOverQ.find('<'))
				cutTwoOverQ = cutOneOverQ[:cutTwoQ]
				
				qualPrint = str(cutTwoOverQ)
				outfile.write(str(cutTwoOverQ))
				outfile.write(str("\n"))
				
	outfile.close()
	print "...Finished"
main()
