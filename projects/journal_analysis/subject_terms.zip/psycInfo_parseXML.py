import string

def main():

	outfile = open("subjectList.txt" , "w")

	fname = raw_input("Enter File Name: ")
	
	#if len(fname) == 0:
		#print "Assuming"
		#fname = "/home/daniel/Desktop/psycINFO1.xml"
	try:
		infile = open(fname, "r")
	except:
		print "File not found, please start over."
		exit()

	print "Reading File..."

	for line in infile: 
		
		chunk = string.split(line)
		
		chunkCount = len(chunk)
		
		if chunkCount == 0: 
			continue
		if chunkCount >= 1:
				if chunk[0] == '<rec':
					resultIdStr = str(chunk[1])
					
					exciseIdStr = resultIdStr[10:]
					
					endLoc = int(exciseIdStr.find('"'))
					
					exciseIdStr2 = exciseIdStr[0:endLoc]
					
					outfile.write("\n"+str(exciseIdStr2)+"\n")
					
				if chunk[0] == '<subj':
					resultSubStr0 = str(chunk[1:])
					
					resultSubStr1 = resultSubStr0.replace('\'','')
					resultSubStr2 = resultSubStr1.replace(',','')
					resultSubStr3 = resultSubStr2.replace('"','')
					
					typeLoc = int(resultSubStr3.find(">"))
					resultSubStr4 = resultSubStr3[typeLoc+1:]
					
					closeLoc = int(resultSubStr4.find('<'))
					resultSubStr5 = resultSubStr4[:closeLoc]
					
					outfile.write(str(resultSubStr5))
					outfile.write(str("\n"))
	outfile.close()
	print "...Finished"
main()
