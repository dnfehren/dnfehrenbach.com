import csv

#file with organization names and ids
orgfile = open('orgs.csv', "rb")
orgreader = csv.reader(orgfile)

#incoming sales data, with organization names instead of ids
salesdatafile = open('sales.csv', "rb")
salesreader = csv.reader(salesdatafile)

#sales data for import with ids added
salesdata_import  = open('sales_data_with_sf_ids.csv', "wb")
saleswriter = csv.writer(salesdata_import, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)

#org names found in the incoming sales data but not in the current list of organizations
contactdata_import  = open('new_clients_from_sales_report.csv', "wb")
contactwriter = csv.writer(contactdata_import, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)

#sales data from orgs not in the database
sales_importlater  = open('sales_data_waiting_for_ids.csv', "wb")
latersaleswriter = csv.writer(sales_importlater, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)

#read organization csv file into dictionary
orgdict = {}

for row in orgreader:
	orgdict[row[0]] = row[1]

orgfile.close()

srownum = 0
crownum = 0
orgloc = 0

#create list of keys (org names) from the organization list
matchlist = orgdict.keys()

newcontactlist = []

#read the sales csv file line by line checking and replacing org names with ids
for row in salesreader: 
    #get header row
	if srownum == 0:
		orgloc = row.index('Organization Name')
		saleswriter.writerow(row)
		contactwriter.writerow(row)
		latersaleswriter.writerow(row)
		srownum += 1
		crownum += 1
	#get other rows
	else:
		#if the contact name in the specified location 
		#is not found in the dictionary print the row to a new contact sheet
		#also print a sheet of all sales data rows that cannot be matched to current orgs
		if row[orgloc] not in orgdict:
			if row[orgloc] not in newcontactlist:
				newcontactlist.append(row[orgloc])
				contactwriter.writerow(row)
			crownum += 1
			latersaleswriter.writerow(row)
		#loop through the keys of the org dictionary
		for element in matchlist:
			#match the keys agains the org location data in the row
			if element == row[orgloc]:
				#if org name at location matches a key
				row[orgloc] = orgdict[element]
				#replace the org name with the value connected to that key
				saleswriter.writerow(row)
				#write out to file with ids instead of names
				srownum += 1

salesdatafile.close()
salesdata_import.close()
contactdata_import.close()
sales_importlater.close()

finalscount = srownum -1
finalccount = crownum -1
finalnewccount = len(newcontactlist)

print " "
print "Number of sales rows changed for import = %s" %(finalscount, )
print " "
print "Use sales_data_with_sf_ids.csv for importing to SF."
print "This file does not include any organizations not already in your SF database"
print " "
print "Number of new organizations found in the data sheet = %s" %(finalnewccount, )
print "Number of sales in sheet not associated with organization in the database = %s" %(finalccount, )
print " "
print "A listing of new organizations can be found in"
print "new_clients_from_sales_report.csv"
print " "
print "The sales data rows not added can be found in"
print "sales_data_waiting_for_ids.csv"
print " "
print "These organizations must be added to SF and their ids added" 
print "to orgs.csv before importing remaining sales data"
print " "



