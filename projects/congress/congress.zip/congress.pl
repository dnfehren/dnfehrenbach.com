#Daniel Fehrenbach
#dnfehrenbach@gmail.com
#3-17-2010

# Script to scrapte the congressional biography website, start and stop sessions are hard coded but could be changed to take user input (w/ validation)
# outputs a sqlite3 database (code is also in here to produce a simple tab delimited text file)

# needs WWW::Mechanize, DBI and DBD::SQLite installed, and optionally SQLite3 if you want to use the command line to query the db afterwards

#----------------------------------------------------------------------------
#
#		Preparation
#
#----------------------------------------------------------------------------

use WWW::Mechanize;
use DBI;

#connect to sqlite3 database and create table
$dbase = DBI->connect( "dbi:SQLite:congress_bios.db" ) || die "Cannot connect: $DBI::errstr";
$dbase->do( "CREATE TABLE congress_members (id INTEGER PRIMARY KEY, last_name, first_name, birth_year, death_year, position, party, state, session_age, session_num, session_start_year, session_stop_year)");

#use these lines to print a tab delimted text file instead of using the database
#open(OUTS, ">full_congress_bios.txt")||die("could not open biography file\n");
#print OUTS "last_name\tfirst_name\tbirth_year\tdeath_year\tposition\tparty\tstate\tsession_num\tsession_age\tsession_start_year\tsession_stop_year\n";

# initialize www mechanize object
my $mech = WWW::Mechanize->new();

#initialize counting variable
$member_count = 0;

#begin gathering data from congressional session (as of 3-2010 it goes from 1 to 111)
$start_session = 100;

#end the data gathering at this congressional session (max is 111)
$stop_session = 111;

#----------------------------------------------------------------------------
#
#		Processing
#
#----------------------------------------------------------------------------

print "Starting to gather data.\n";

#for each year (defined by start_year and stop_year) fill in the form on the bio page and scrape the data
# into the bio collector database
for($session = $start_session; $year <= $stop_session; $year++){  

	$search_url = "http://bioguide.congress.gov/biosearch/biosearch.asp";

	$mech->get($search_url);

	#insert the year from the for loop into the congress field on the search page
	$mech->field('congress',$session);
	
	#'click' button (that has no name, but it is the first button on the page) to submit the search year
	$search_response = $mech->click_button(number => '1');	

	# print out redirects and errors if they occur
	if ($search_response->is_redirect){
		print STDERR __LINE__, " Redirect to ", $search_response->header('Location'), "\n";
	} 
	elsif ($search_response->is_error){
		print STDERR __LINE__, " Error: ", $search_response->status_line, " ", $search_response;
	}
	else{
		#get the page back from the server and collect it as a string
		$content = $search_response->as_string;
		
		#first regex used to find the rows after the header and intro informatio in the content
		while($content =~ m/<tr><td><A HREF=\S+>(.*\n.*)<\/tr>/g){
			
			#grabs the useful portion of the html row
			$member_row = $1;
			
			#extracts the biographical information from the rest of the row data and saves it into specific vars
			($last_name, $first_name, $birth_year, $death_year, $position, $party, $state, $session_num, $session_start_year, $session_stop_year) = ($member_row =~ m/(.*),\s(.*)<\/A><\/td><td>([0-9]+)-([0-9]{4}|&nbsp;)<\/td>\n<td>([A-Z][a-z]+)<\/td><td>([A-Z][a-z]+)<\/td><td align="center">([A-Z]{2})<\/td><td align="center">([0-9]+)<br>\(([0-9]{4})-([0-9]{4})\)<\/td>/g);
			
			#takes the last name out of ALL CAPS
			$last_name = ucfirst(lc($last_name));
			
			#[hack]removes ' from names for easier insertion into database
			$last_name =~ s/'//;
			$first_name =~ s/'//;
			
			#finds the age of that particular member by subtracting thier listed birth year from the year that the current session started
			$session_age = ($session_start_year-$birth_year);
			
			#to print to a flat file instead of a database
			#print OUTS "$last_name\t$first_name\t$birth_year\t$death_year\t$position\t$party\t$state\t$session_num\t$session_age\t$session_start_year\t$session_stop_year\n"; 
			
			#status message
			print "Inserting row # $member_count\n";
			
			#database insert, first null is space for an id column
			$dbase->do( "INSERT INTO congress_members VALUES (NULL, '$last_name', '$first_name', '$birth_year', '$death_year', '$position', '$party', '$state', '$session_age', '$session_num', '$session_start_year', '$session_stop_year')");
			
			#advance count for status message
			$member_count++;
			
			} #closes while loop
		} #closes else statement
} #close year loop
